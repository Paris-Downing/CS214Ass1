//Paris Downing and Nikita Zala

#ifndef _SIMPLECSVSORTERH_
#define _SIMPLECSVSORTERH_
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//struct declaration
typedef struct movies
{
	//holds all the attributes of one movie 
	char **array;
}movies;

/*
int printStruct(struct movies m)
{
	int counter;
	for(counter = 0; counter < 28; counter++)
		printf("%s ", m.array[counter]);
	printf("\n");
}
*/

#endif
