//Nikita Zala and Paris Downing

//isCSV and getColumn both work. The code is breaking after the check for -c -o -d. it is time to sort every file in the directory
//after this, you should probably change the output.csv. it should be sorted something or other. change outputDir
#include "scannerCSVsorter.h"
#include "mergesort.c"
#include <dirent.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

//stores the header of the document
char **array_tokens;

//stores the number of attributes in one line
int attributes;

//stores the number of lines the document has
int f_size;

//tells which col in the doc will be sorted
int sortCol = -1;

//holds all the pid values
int *pidHolder;

int pidCounter;

//Function declaration
void trimTrail(char * str);
struct movies* getData(FILE *file, char *outputStr, char *sortBy);
void printOutput(struct movies *mo, char *outputFile);
int getF_size(FILE *file);
int getCurrDirectory(char *directory, char *outputDir, char *sortBy);
int isCSV(char *file);
int getColumn(char *file);

//receives a sortBy word, the starting dir, and the dir where all the final entries will be stored.
int main(int argc, const char * argv[]) 
{
	int j;

/*
	FILE *file;
	//checks to make sure the file I am reading in works
	if((argc == 3) || (argc == 5) || (argc == 7))
		file = fopen("/testingFolder/doubleTest/anotherDoc.csv", "r+");
	else
	{
		printf("wrong number of arguments\n");
		return 0;
	}
    	if(file==NULL)
	{
       		printf("File error. File not found.\n");
        	return 0;
    	}
	
	getF_size(file);
	printf("f_size: %d\n", f_size);
	printf("attributes: %d\n", attributes);
	int w = isCSV("/testingFolder/doubleTest/anotherDoc.csv");
	printf("%d\n", w);
*/

	//figures out what to do with the user's inputs. If 0, put file in curr directory
	char *outputDir;
//	char *inputFile;
//	inputFile = "movie_metadata.csv";
	char *directory;
	//the location in the input of the string that the documents will be sorted by
	int cLoc;
	if(argc == 3)
	{
		if(strcmp(argv[1], "-c") != 0)
		{
			printf("-c necessary to sort\n");
    			//fclose(file);
			return -1;
		}
		else
		{
			cLoc = 2;
			outputDir = ".";
			directory = ".";
			/*
			char cwd[1024];
    			chdir("/path/to/change/directory/to");
    			getcwd(cwd, sizeof(cwd));
    			printf("Current working dir: %s\n", cwd);
			directory = malloc(sizeof(char) * sizeof(cwd));
			directory = cwd;
			*/
		}
	}
	else if(argc == 5)
	{
		if((strcmp(argv[1], "-c") != 0) && (strcmp(argv[3], "-c") != 0))
		{
			printf("-c necessary to sort\n");
    			//fclose(file);
			return -1;
		}
		else
		{
			if(strcmp(argv[1], "-c") == 0)
			{
				if(strcmp(argv[3], "-d") == 0)
				{
					//output in same folder as source file
					outputDir = ".";
					directory = argv[4];
				}
				else if(strcmp(argv[3], "-o") == 0)
				{
					outputDir = argv[4];
					directory = ".";
					/*
					char cwd[1024];
    					chdir("/path/to/change/directory/to");
    					getcwd(cwd, sizeof(cwd));
    					printf("Current working dir: %s\n", cwd);
					directory = malloc(sizeof(char) * sizeof(cwd));
					directory = cwd;
					*/
				}
				cLoc = 2;
			}
			else if(strcmp(argv[3], "-c") == 0)
			{
				if(strcmp(argv[1], "-o") == 0)
				{
					outputDir = argv[2];
					directory = ".";
					/*
					char cwd[1024];
    					chdir("/path/to/change/directory/to");
    					getcwd(cwd, sizeof(cwd));
    					printf("Current working dir: %s\n", cwd);
					directory = malloc(sizeof(char) * sizeof(cwd));
					directory = cwd;
					*/
				}
				else if(strcmp(argv[1], "-d") == 0)
				{
					//outputFile is same directory of source file
					outputDir = ".";
					directory = argv[2];
				}
				cLoc = 4;
			}
		}
	}
	else if(argc == 7)
	{
		if((strcmp(argv[1], "-c") != 0) && (strcmp(argv[3], "-c") != 0) && (strcmp(argv[5], "-c") != 0))
		{
			printf("-c necessary to sort\n");
    			//fclose(file);
			return -1;
		}
		else
		{
			if(strcmp(argv[1], "-c") == 0)
			{
				if((strcmp(argv[3], "-d") == 0) && (strcmp(argv[5], "-o") == 0))
				{
					directory = argv[4];
					outputDir = argv[6];
				}
				else if((strcmp(argv[3], "-o") == 0) && (strcmp(argv[5], "-d") == 0))
				{
					outputDir = argv[4];
					directory = argv[6];
				}
				cLoc = 2;
			}
			else if(strcmp(argv[3], "-c" == 0))
			{
				if((strcmp(argv[1], "-d") == 0) && (strcmp(argv[5], "-o") == 0))
				{
					outputDir = argv[6];
					directory = argv[2];
				}
				else if((strcmp(argv[1], "-o") == 0) && (strcmp(argv[5], "-d") == 0))
				{
					outputDir = argv[2];
					directory = argv[6];
				}
				cLoc = 4;
			}
			else if(strcmp(argv[5], "-c" == 0))
			{
				if((strcmp(argv[1], "-d") == 0) && (strcmp(argv[3], "-o") == 0))
				{
					outputDir = argv[4];
					directory = argv[2];
				}
				else if((strcmp(argv[1], "-o") == 0) && (strcmp(argv[3], "-d") == 0))
				{
					outputDir = argv[2];
					directory = argv[4];
				}
				cLoc = 6;
			}
		}
	}
	else
	{
		printf("incorrect amount of arguments given\n");
		return 0;
	}
	printf("cLoc: %d\n", cLoc);
	printf("inDir: %s\n", directory);
	printf("outDir: %s\n", outputDir);
	int pid = getpid();
	pidHolder = calloc(255, sizeof(int));
	pidCounter = 0;
	printf("Initial pid: %d\n", pid);
	getCurrDirectory(directory, outputDir, argv[cLoc]);
	
	printf("PIDS of all child processes: ");
	for(j = 1; pidHolder[j] != 0; j++)
	{
		if(j == 1)
			printf("%d", pidHolder[j]);	
		else
			printf(", %d", pidHolder[j]);
	}
	printf("\n");
	printf("Total number of processes: %d\n", pidCounter);
	//argv[cLoc] will give a string to the attribute that it will be sorted by

	//gets the number of attributes in header
	//attributes = getAttributeNumber(file);
	//printf("%d\n",attributes);
	//printf("%d\n", f_size);	


/*
	//creates the structure that will be used to hold all the data
	array_tokens = calloc(attributes,sizeof(char*));
    	struct movies* data = getData(file, outputDir);
    	fclose(file);
	
	//finds sortBy index
    	int sortBy = 1;
	int isSortable = 0;
	for(j = 0; j < attributes; j++)
	{
		if(strcmp(argv[cLoc], data[0].array[j]) == 0)
		{
			sortBy = j;
			isSortable = 1;
			break;
		}
	}
	if(isSortable == 0)
	{
		printf("Your sorting input does not match up to what is in the document\n");
		free(data);
		return 0;
	}
	//printf("cloc: %d\n", cLoc);
	//printf("sortBy: %d\n", sortBy);
	
	//directory = "/ilab/users/prd45/Systems";
	printf("dir: %s\n", directory);
	int pid = getpid();
	printf("Initial pid: %d\n", pid);
	getCurrDirectory(directory);

	//calls mergesort to sort the data
    	mergesort(data, 1, f_size - 1, sortBy);
*/
	/*
	for(j = 0;j < f_size-1;j++)
		printf("%s\n",data[j].array[sortBy]);
	*/
	//we were having difficulties printing the header, so the header is stored separetly in the document 
/*
	int structure_array_variable;
	for(j = 0;j < attributes;j++)
	{
		data[0].array[j] = array_tokens[j]; 
	}
	printOutput(data, outputDir);
*/
    return 0;
}

//gets F_size, as well as attributes
int getF_size(FILE *file)
{
	printf("in getF_size\n");
	f_size = 0;
	attributes = 0;
	printf("yo\n");
	printf("pre f_size: %d\n", f_size);
	printf("pre attributes: %d\n", attributes);
	char ch = fgetc(file);
	printf("%c\n", ch);

	//finds the number of lines that the code will scan in
	while(!feof(file))
	{
		//printf("Line: %d\n", f_size);
		//printf("in for\n");
		if(ch == '\n')
		{
			f_size++;
		}
		else if((ch == ',') && (f_size == 0))
			attributes++;
		ch = fgetc(file);
	}
	attributes++;
	close(file);
	printf("getF_Size: %d\n", f_size);
	printf("getAttributes: %d\n", attributes);
	return f_size;
}

struct movies* getData(FILE *file, char *outputStr, char *sortBy)
{
	printf("in getData\n");
	int j;
	getF_size(file);
    
    	fseek(file, 0, SEEK_SET);
 
    	char buff[1024];
	char title[1024]; 

    	//columns
    	fgets(title,1024,file);
    	char* token = strtok(title, ",");
    	int a= 0;

	//sets everything in mo to 0
    	movies *mo = malloc(sizeof(movies) * f_size);
	for(j = 0; j < f_size; j++)
		mo[j].array = calloc(attributes, sizeof(char*)); 
	printf("after the calloc\n");
	printf("attributes: %d\n", attributes);
	printf("output: %s\n", outputStr);

	/*
	//finds which column is going to be sorted
	for(j = 0; j < attributes; j++)
	{
		printf("curr :%d\n", mo[0].array[0]);
		if(strcmp(mo[0].array[j],sortBy) == 0)
		{	
			printf("MADEEEE IT\n");
			sortCol = j;
			break;
		}
	}
	printf("SORTCOL: %d\n", sortCol);
	if(sortCol = -1)
	{
		printf("Does not have a sortable column\n");
		return -1;
	}
	*/

    	while (token) 
	{
		printf("%s\n", token);
        	array_tokens[a] = token;
		token = strtok(NULL, ",");
        	a++;
     	}

	FILE *outputFile = fopen(outputStr, "w+");
	//prints the header in the csv file
	for(j = 0; j < attributes; j++)
	{
		fprintf(outputFile, "%s", array_tokens[j]);
		if(j!= attributes)
			fprintf(outputFile,",");
	}
        fclose(outputFile);
	
	//scans in the rest of the information and stores it in pointer mo
    	int w;
    	for(w = 0; w < attributes; w++)
		mo[0].array[w] = array_tokens[w];
    	int c=0;
	//printf("%d\n",f_size);
    	while (c<f_size-1)
	{
		//main rows
    		fgets(buff,1024,file);
    		char *str = strdup(buff);
    		char *temp = strsep(&str, ",");
		int i;
    		for(i=0;i<attributes;i++){
      			while(isspace((unsigned char)*temp)) temp++;
      		trimTrail(temp);
      		mo[c+1].array[i]=temp;
      		temp = strsep(&str, ",");
    	}
    	c+=1;
 }     
	printf("end of getDATA\n");
  return mo;
}

void trimTrail(char *str){
    int index, i;
    index = -1;
    
    //Find last index of non-white space character
    i = 0;
    while(str[i] != '\0')
    {
        if(str[i] != ' ' && str[i] != '\t' && str[i] != '\n')
        {
            index= i;
        }
        i++;
    }
    //Mark next character to last non-white space character as NULL
    str[index + 1] = '\0';
}

//prints the information out in a csv file
void printOutput(struct movies *mo, char *outputFile)
{
        FILE *file = fopen(outputFile, "a");
        int i;
        int j;
        for(i = 1; i < f_size; i++)
        {
                for(j = 0; j < attributes; j++)
                {
                        fprintf(file, "%s", mo[i].array[j]);
	
			if(j != attributes - 1)
				fprintf(file, ",");
                }
                fprintf(file, "\n");
        }
	fclose(file);
}

//lists all the files in the current directory
int getCurrDirectory(char *directory, char *outputDir, char *sortBy)
{
	printf("***directory: %s\n", directory);
	DIR *currDirectory = opendir(directory);
	struct dirent *dir = readdir(currDirectory);
	int pidCounter = 1;
	if(currDirectory)
    	{
       		while (dir != NULL)
        	{
			if(isCSV(dir->d_name) == 0)
			{
				printf("%s is CSV\n", dir->d_name);
				FILE *file = fopen(dir->d_name, "r+");
				array_tokens = calloc(attributes,sizeof(char*));
				//getF_size(file);
    				struct movies* data = getData(file, outputDir, sortBy);
    				mergesort(data, 1, f_size - 1, sortBy);
			}

			//tempDir gets directory path, dir->d_name gets various files/folders in directory
			char* tempDir = calloc((sizeof(directory) + sizeof(dir->d_name) + 1), sizeof(char));
			//printf("^^^%s %s\n", directory, dir->d_name);
			strcat(tempDir, directory);
			strcat(tempDir, "/");
			strcat(tempDir, dir->d_name);
			if((dir->d_name != NULL ) && (isDirectory(tempDir)) && (strcmp(dir->d_name, ".") != 0) && (strcmp(dir->d_name, "..") != 0))
			{
				//printf("%s\n", tempDir);
				printf("%s is directory\n", dir->d_name);
				int pid1;
				if(pid1 = fork())
				{ 
					char spid1[5];
					printf("in fork\n");
					pidHolder[pidCounter] = pid1;
					/*
					if(pidCounter == 1)
					{
						printf("if\n");
						//itoa(pid1, spid1, 10);
						//printf("%s\n", spid1);
						//strcat(pidHolder, pid1);
						printf("%s\n", pidHolder);
					}
					else
					{
						printf("else\n");
						//strcat(pidHolder, ", ");
						//strcat(pidHolder, pid1);
					}
					*/
					pidCounter++;
					printf("piDCOUNTER: %d\n", pidCounter);
					printf("about to recurse\n");
					if(strcmp(outputDir, ".") == 0)
					{
						outputDir = tempDir;
					}
					printf("outputDir: %s\n", outputDir);
					getCurrDirectory(tempDir, outputDir, sortBy);
				//	directory = tempDir;
				}
			}
			dir = readdir(currDirectory);
        	}
        	closedir(currDirectory);
    	}
		
	//printf("Total number of processes: %d\n", pidCounter + 1);
	//make it return pidCounter
    return 0;
}

int isCSV(char *file)
{
	printf("in ISCSV\n");
	/*
	char *lastOccur = strrchr(file, '.');
	if((lastOccur && (strcmp(lastOccur, ".csv"))==0))// && (strstr(file,"-sorted") == NULL) && (getColumn(file) == 0))
	{
		printf("dir: %s\n", file);
		if((strstr(file,"-sorted-")== NULL))// && (getColumn(file)==0))
		{	
				int col = getColumn(file);
				printf("col: %d\n", col);
				int n = getColumn(file);			
				printf("%d\n",n);
				printf("%s\n", file);
				return 0;
		}
	}
	return -1;
	*/
	char *lastOccur = strrchr(file, '.');
	//int w = getColumn(file);
	//printf("%s %d\n", file, w);
	if((strstr(file,"-sorted-") == NULL) && (lastOccur && !strcmp(lastOccur, ".csv")))// && (getColumn(file) != -1))
		return 0;
	else
		return -1;
}

//checks if it is a normal directory 
int isDirectory(const char *path)
{
	//printf("isDir: %s\n", path);
	struct stat statbuf;
	if (stat(path, &statbuf) != 0)
	{
		printf("%d\n", statbuf);
       		return 0;
	}
   	return S_ISDIR(statbuf.st_mode);
}

//checks to make sure every row has the same amount of commas
int getColumn(char *file)
{
	printf("in getColumn\n");
	FILE *myFile = fopen(file, "r");
	printf("%s\n", file);
   	int currChar = fgetc(myFile);
	int commaCounter = 0;
	int lineCounter;
  
	for(lineCounter = 0; lineCounter < f_size;lineCounter++)
	{
		printf("Line: %d\n", lineCounter);
		printf("f_size: %d\n", f_size);
		printf("attribute: %d\n", attributes);
		while(currChar != '\n')
		{
			if(currChar == ',')
			{
				commaCounter++;
				printf("in if\n");
			}
			/*
			if(lineCounter == 65)
				if(currChar != ',')
				printf("%c", currChar);
				else
				printf(" ||||  ");
			*/
			currChar = fgetc(myFile);
		}
		/*
		printf("line number: %d\n", lineCounter);
		printf("commas: %d\n", commaCounter);
		printf("attributes: %d\n", attributes);
		*/
		//if one of the lines has the wrong amount of commas, return -1
		if((currChar == '\n') && (commaCounter + 1 != attributes))
			return -1;
		else if(currChar == '\n')
		{
			commaCounter = 0;
			currChar = fgetc(myFile);
		}
	}
   	fclose(myFile);
	return 0;
}
